
import './App.css';
import Header from './components/header';
import Body from './components/body';
//import { Modal } from 'bootstrap';
import Modal from 'react-modal';

Modal.setAppElement('#root')
function App() {
  return (
    <div className="App">
      <Header/>
      <Body />
    </div>
  );
}
export default App;
