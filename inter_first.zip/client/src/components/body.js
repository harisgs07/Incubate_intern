import React from 'react';
import '../App.css';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import Modal from 'react-modal';
import { useState } from 'react';
import {Row} from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import Table from 'react-bootstrap/Table';
//import { Component } from 'react';
const axios = require('axios');


function Body() {

    
    const [Isopen1, setisopen1] =  useState(false)
    const [Isopen2, setisopen2] =  useState(false)
    const [name,addname] = useState("")
    const [email,addname1] = useState("")
    const [phone,addname2] = useState("")
    const [address,addname3] = useState("")
    const [secondaddress,addname4] = useState("")

    const [tasklist1, settasklist] = useState([])
    const gettasklist = () => {
        axios.get('http://localhost:4005/table')
        .then((respose)=>respose.data)
        .then ((respose)=>{
            settasklist(respose)
        })
    }
    gettasklist()
    function onDel() {
        axios.post('http://localhost:4005/delrow',{
            name,email,phone,address,secondaddress
    
        });
        gettasklist()
        setisopen1(false)
    }

function onAddnew() {
    //gettasklist()
    axios.post('http://localhost:4005/addnew',{
        name,email,phone,address,secondaddress

    });
    gettasklist()
   setisopen2(false)
    
}

  return (
    <div >
      <div style={{paddingTop:"40px",alignContent:"center"}}>
          <div>
                <div style={{float:"right",height:"60px"}}> 
                    <div>
                    <Button onClick={()=>setisopen1(true)} variant="danger">Delete row</Button>{' '}
                    <Button onClick={()=>setisopen2(true)} variant="success">Add Row</Button>{' '}
                    </div>                 
                </div>
          </div>
          <div style={{paddingLeft:"20px"}}>
          <Table striped bordered hover size="sm">
              
                <thead>
                    <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Second Address</th>
                    </tr>
                </thead>
                <tbody>
               {
                   tasklist1.map((obj,index)=>{
                       return(
                        <tr>
                        <td>{obj.name}</td>
                        <td>{obj.email}</td>
                        <td>{obj.phone}</td>
                        <td>{obj.address}</td>
                        <td>{obj.saddress}</td>
                        </tr>

                       );
                   })
               }
                   
                </tbody>
            </Table>
          </div>
      </div>
      
        <Modal 
        style={
            {
            overlay:{
                    backgroundColor:"grey"},
            content:{
                    border:"0",
                    marginTop:"8%",
                    marginLeft:"30%",
                    width:"40%",
                    height:"60%",
                    borderradius: "20px"}
            }}
        isOpen={Isopen1} 
        onRequestClose={()=>setisopen1(false)}>    
            <div style={{marginLeft:"30px",marginRight:"30px"}}>
        <Form >
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalEmail">
                <Col sm={12}>
                <Form.Control  onChange={e=>addname(e.target.value)}
                 type="text" placeholder="Name" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalPassword">
                <Col sm={12}>
                <Form.Control onChange={e=>addname1(e.target.value)}
               
                type="email" placeholder="Email" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalNumber">
                <Col sm={12}>
                <Form.Control onChange={e=>addname2(e.target.value)}
                type="Number" placeholder="mobile Number" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalAdress">
                <Col sm={12}>
                <Form.Control onChange={e=>addname3(e.target.value)}
                 type="text" placeholder="Address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalOther">
                <Col sm={12}>
                <Form.Control onChange={e=>addname4(e.target.value)} type="text" placeholder="other address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Col sm={{ span: 10, offset: 2 }}>
                <Button onClick={onDel} style={{marginLeft:"20px",width:"210px"}}variant="danger">Delete</Button>{' '}
                </Col>
            </Form.Group>
        </Form>
    </div>
        </Modal>
        <Modal 
            style={
            {
            overlay:{        
                backgroundColor:"gray",
                pacity:"300px"
                },
            content:{
                border:"0",
                marginTop:"8%",
                marginLeft:"30%",
                width:"40%",
                height:"70%",
                borderradius: "20px"}
            }}
        isOpen={Isopen2}
        onRequestClose={()=>setisopen2(false)}>
            <div style={{marginLeft:"30px",marginRight:"30px"}}>
        <Form >
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalEmail">
                <Col sm={12}>
                <Form.Control  onChange={e=>addname(e.target.value)}
                 type="text" placeholder="Name" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalPassword">
                <Col sm={12}>
                <Form.Control onChange={e=>addname1(e.target.value)}
               
                type="email" placeholder="Email" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalNumber">
                <Col sm={12}>
                <Form.Control onChange={e=>addname2(e.target.value)}
                type="Number" placeholder="mobile Number" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalAdress">
                <Col sm={12}>
                <Form.Control onChange={e=>addname3(e.target.value)}
                 type="text" placeholder="Address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalOther">
                <Col sm={12}>
                <Form.Control onChange={e=>addname4(e.target.value)} type="text" placeholder="other address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Col sm={{ span: 10, offset: 2 }}>
                <Button onClick={onAddnew} 
                style={{marginLeft:"20px",width:"210px"}}variant="success">Submit</Button>{' '}
                </Col>
            </Form.Group>
        </Form>
    </div>
        </Modal>
    </div>
  );
}

export default Body;
