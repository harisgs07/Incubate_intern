

import React from 'react';
import '../App.css';
import Button from 'react-bootstrap/Button';
import { useState } from 'react';
import {Row} from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import 'bootstrap/dist/css/bootstrap.min.css';
import Body from './body';
const axios = require('axios');

function Delform() {
    const [name,addname] = useState("")
    const [email,addname1] = useState("")
    const [phone,addname2] = useState("")
    const [address,addname3] = useState("")
    const [secondaddress,addname4] = useState("")

    const [tasklist1, settasklist] = useState([])
    const gettasklist = () => {
        axios.get('http://localhost:4005/table')
        .then((respose)=>respose.data)
        .then ((respose)=>{
            settasklist(respose)
            console.log(tasklist1)
        })
    }

    function onDel() {
        axios.post('http://localhost:4005/delrow',{
            name,email,phone,address,secondaddress
    
        });
        gettasklist()
        Body.setisopen2(false)
    }

  return (
    <div style={{marginLeft:"30px",marginRight:"30px"}}>
        <Form >
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalEmail">
                <Col sm={12}>
                <Form.Control  onChange={e=>addname(e.target.value)}
                 type="text" placeholder="Name" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalPassword">
                <Col sm={12}>
                <Form.Control onChange={e=>addname1(e.target.value)}
               
                type="email" placeholder="Email" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalNumber">
                <Col sm={12}>
                <Form.Control onChange={e=>addname2(e.target.value)}
                type="Number" placeholder="mobile Number" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}  className="form-controls" controlId="formHorizontalAdress">
                <Col sm={12}>
                <Form.Control onChange={e=>addname3(e.target.value)}
                 type="text" placeholder="Address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row} className="form-controls" controlId="formHorizontalOther">
                <Col sm={12}>
                <Form.Control onChange={e=>addname4(e.target.value)} type="text" placeholder="other address" />
                </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Col sm={{ span: 10, offset: 2 }}>
                <Button onClick={onDel} style={{marginLeft:"20px",width:"210px"}}variant="danger">Delete</Button>{' '}
                </Col>
            </Form.Group>
        </Form>
    </div>
  );
}

export default Delform;
