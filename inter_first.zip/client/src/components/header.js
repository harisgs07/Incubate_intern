
import React from 'react';
import '../App.css';

function Header() {
  return (
    <div style={{backgroundColor:"grey",height:"90px"}}>
      <div className="rows" style={{paddingTop:"10px"}}>
            <div className="row" 
            style={{marginLeft:"20px",
            paddingTop:"10px", 
            float:"left",
            backgroundColor:"red", 
            width:"80px",
            height:"60px"}}> 

                <label style={{marginLeft:"10px",marginTop:"7px"}}>Logo</label>
            </div>
            <div className="row" style={{marginLeft:"20px",
            paddingTop:"10px", float:"left",
            }} >
                Brand Name
            </div>    
      </div>
    </div>
  );
}

export default Header;
