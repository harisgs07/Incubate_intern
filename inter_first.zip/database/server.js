const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const con = require('./db');
const { response } = require('express');
//const { errorMonitor } = require('events');

//const { connect } = require('./db');
const app = express();
app.use(cors());
app.use(bodyParser.json())
app.get('/table',(req,res)=>{
    const sql="select * from table_react";
    con.query(sql,(err,response)=>{
        if(err) console.log(err)
    else res.send(response)})

})
app.post('/addnew',(req,res)=>{
    const sql = "insert into table_react (email,name,phone,address,saddress) values(?,?,?,?,?)"
    con.query(sql,[req.body.email,req.body.name,req.body.phone,req.body.address,req.body.secondaddress])
})
app.post('/delrow',(req,res)=>{
    const sql = "delete from table_react where email=? and name=? and phone=? and address=? and saddress=?"
    con.query(sql,[req.body.email,req.body.name,req.body.phone,req.body.address,req.body.secondaddress])
})

    app.listen(4005,()=>{

    console.log("running");
})
